## Bank-DBMS

#### Introduction 

People want money for personal and commercial purposes and banks are the oldest lending institutions in Indian scenario. 
They are providing facilities to all citizens for their own
purposes according to their terms. 

To survive in this modern market every bank implements various novel and innovative ideas, strategies as well as advanced technologies. 

For that they give each and every minute detail about their
institution and projects to public. They are providing ample facilities
to satisfy their customers i.e. Net Banking, Mobile Banking, Door to
Door facility, Instant facility, Investment facility, Demat facility,
Credit Card facility, Loans and Advances, Account facility etc. And
such banks get success to create their own image in public and
corporate world.

#### Description

This project has been developed to carry out
the processes easily and quickly, which is not possible with the
manuals systems, which are overcome by this software. 

Creating and
managing requirements is a challenge of IT, systems and product
development projects or indeed for any activity where you have to
manage a contractual relationship. Organization need to effectively
define and manage requirements to ensure they are meeting needs of
the customer, while proving compliance and staying on the schedule
and within budget. The impact of a poorly expressed requirement
can bring a business out of compliance or even cause injury or death.


Requirements definition and management is an activity that can
deliver a high, fast return on investment. Thus, above features of this
project will save transaction time and therefore increase the
efficiency of the system.

#### ER Diagram 

![Diagram2](https://user-images.githubusercontent.com/33753405/70563167-c5cf1400-1bb3-11ea-890b-c28fa84396c5.png)
